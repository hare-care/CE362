Digit Counter Base 3 (Advanced Benchmark):

 - Program will take the largest positive immediate value (2047)
 - Multiply this value by 100
 - Compute the number of base 3 digits in nested loops which execute a total of 102357 times
 - Now it goes into memory, computes and stores the first 10 powers of 3 (starting at MEMORY Location -x80)
 - Note that powers of 3 each represent an increment to the base 3 digits of numbers.  